#!/bin/bash
cd `dirname $BASH_SOURCE`
java $@
